-- MySQL dump 10.13  Distrib 5.5.13, for Win32 (x86)
--
-- Host: localhost    Database: zanda_nemlog
-- ------------------------------------------------------
-- Server version	5.5.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `akt_stat`
--

DROP TABLE IF EXISTS `akt_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `akt_stat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mikor` datetime NOT NULL,
  `akt_1_perc` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_5_perc` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_10_perc` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_15_perc` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_1_ora` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_24_ora` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_3_nap` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_7_nap` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ossz` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `akt_stat`
--

LOCK TABLES `akt_stat` WRITE;
/*!40000 ALTER TABLE `akt_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `akt_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aktivitasi_mintak`
--

DROP TABLE IF EXISTS `aktivitasi_mintak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aktivitasi_mintak` (
  `uid` smallint(5) unsigned NOT NULL,
  `mikor` time NOT NULL DEFAULT '00:00:00',
  `barmikor` tinyint(3) NOT NULL DEFAULT '0',
  `wd1` tinyint(3) NOT NULL DEFAULT '0',
  `wd2` tinyint(3) NOT NULL DEFAULT '0',
  `wd3` tinyint(3) NOT NULL DEFAULT '0',
  `wd4` tinyint(3) NOT NULL DEFAULT '0',
  `wd5` tinyint(3) NOT NULL DEFAULT '0',
  `wd6` tinyint(3) NOT NULL DEFAULT '0',
  `wd7` tinyint(3) NOT NULL DEFAULT '0',
  `barmikor_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd1_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd2_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd3_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd4_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd5_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd6_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd7_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd15` tinyint(4) NOT NULL DEFAULT '0',
  `wd67` tinyint(4) NOT NULL DEFAULT '0',
  `wd15_norm` smallint(6) NOT NULL DEFAULT '0',
  `wd67_norm` smallint(6) NOT NULL DEFAULT '0',
  UNIQUE KEY `uid_mikor_idx` (`uid`,`mikor`) USING BTREE,
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aktivitasi_mintak`
--

LOCK TABLES `aktivitasi_mintak` WRITE;
/*!40000 ALTER TABLE `aktivitasi_mintak` DISABLE KEYS */;
/*!40000 ALTER TABLE `aktivitasi_mintak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aktivitasok`
--

DROP TABLE IF EXISTS `aktivitasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aktivitasok` (
  `uid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `db` bigint(20) unsigned NOT NULL DEFAULT '0',
  `hetnapja` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tizperc` time NOT NULL DEFAULT '00:00:00',
  UNIQUE KEY `uid_mikor_idx` (`uid`,`mikor`) USING BTREE,
  KEY `uid_tizperc_idx` (`uid`,`tizperc`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aktivitasok`
--

LOCK TABLES `aktivitasok` WRITE;
/*!40000 ALTER TABLE `aktivitasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `aktivitasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aux_tizpercek`
--

DROP TABLE IF EXISTS `aux_tizpercek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_tizpercek` (
  `mikor` time NOT NULL,
  UNIQUE KEY `mikor_idx` (`mikor`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aux_tizpercek`
--

LOCK TABLES `aux_tizpercek` WRITE;
/*!40000 ALTER TABLE `aux_tizpercek` DISABLE KEYS */;
/*!40000 ALTER TABLE `aux_tizpercek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aux_transzfer_tabla`
--

DROP TABLE IF EXISTS `aux_transzfer_tabla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_transzfer_tabla` (
  `bolygo_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `mikor` datetime NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aux_transzfer_tabla`
--

LOCK TABLES `aux_transzfer_tabla` WRITE;
/*!40000 ALTER TABLE `aux_transzfer_tabla` DISABLE KEYS */;
/*!40000 ALTER TABLE `aux_transzfer_tabla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aux_user_aramlasok`
--

DROP TABLE IF EXISTS `aux_user_aramlasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_user_aramlasok` (
  `id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `belepes` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `kilepes` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `szovitag` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aux_user_aramlasok`
--

LOCK TABLES `aux_user_aramlasok` WRITE;
/*!40000 ALTER TABLE `aux_user_aramlasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `aux_user_aramlasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aux_userek`
--

DROP TABLE IF EXISTS `aux_userek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_userek` (
  `id` smallint(5) unsigned NOT NULL,
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `elso_nap` date NOT NULL DEFAULT '0000-00-00',
  `utolso_nap` date NOT NULL DEFAULT '0000-00-00',
  `napok_szama` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd1n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd2n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd3n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd4n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd5n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd6n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wd7n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `akt_cnt_dist_mikor` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `akt_sum_db` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aux_userek`
--

LOCK TABLES `aux_userek` WRITE;
/*!40000 ALTER TABLE `aux_userek` DISABLE KEYS */;
/*!40000 ALTER TABLE `aux_userek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aux_zandakiller`
--

DROP TABLE IF EXISTS `aux_zandakiller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_zandakiller` (
  `x` mediumint(9) NOT NULL DEFAULT '0',
  `y` mediumint(9) NOT NULL DEFAULT '0',
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tulaj_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `kezelo_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `egyenertek` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aux_zandakiller`
--

LOCK TABLES `aux_zandakiller` WRITE;
/*!40000 ALTER TABLE `aux_zandakiller` DISABLE KEYS */;
/*!40000 ALTER TABLE `aux_zandakiller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bolygo_transzfer_log`
--

DROP TABLE IF EXISTS `bolygo_transzfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bolygo_transzfer_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bolygo_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_0` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov_0` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_1` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_2` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(5) NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL,
  `foglalas` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ertek_elotte` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ertek_utana` bigint(20) unsigned NOT NULL DEFAULT '0',
  `veszteseg` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bolygo_transzfer_log`
--

LOCK TABLES `bolygo_transzfer_log` WRITE;
/*!40000 ALTER TABLE `bolygo_transzfer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bolygo_transzfer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bolygok_exim`
--

DROP TABLE IF EXISTS `bolygok_exim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bolygok_exim` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `export` bigint(20) NOT NULL DEFAULT '0',
  `import` bigint(20) NOT NULL DEFAULT '0',
  `hexak_szama` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bolygok_exim`
--

LOCK TABLES `bolygok_exim` WRITE;
/*!40000 ALTER TABLE `bolygok_exim` DISABLE KEYS */;
/*!40000 ALTER TABLE `bolygok_exim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cset_hozzaszolasok_hist`
--

DROP TABLE IF EXISTS `cset_hozzaszolasok_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cset_hozzaszolasok_hist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `szov_id` smallint(5) NOT NULL DEFAULT '0',
  `ki` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mit` varchar(255) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `szov_mikor_idx` (`szov_id`,`mikor`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cset_hozzaszolasok_hist`
--

LOCK TABLES `cset_hozzaszolasok_hist` WRITE;
/*!40000 ALTER TABLE `cset_hozzaszolasok_hist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cset_hozzaszolasok_hist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_kitiltasok`
--

DROP TABLE IF EXISTS `email_kitiltasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_kitiltasok` (
  `email` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_kitiltasok`
--

LOCK TABLES `email_kitiltasok` WRITE;
/*!40000 ALTER TABLE `email_kitiltasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_kitiltasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hajo_transzfer_log`
--

DROP TABLE IF EXISTS `hajo_transzfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hajo_transzfer_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tulaj_1` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(5) NOT NULL DEFAULT '0',
  `forras_id` int(11) NOT NULL DEFAULT '0',
  `tulaj_2` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(5) NOT NULL DEFAULT '0',
  `cel_id` int(11) NOT NULL DEFAULT '0',
  `ertek` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hajo_transzfer_log`
--

LOCK TABLES `hajo_transzfer_log` WRITE;
/*!40000 ALTER TABLE `hajo_transzfer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `hajo_transzfer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `helyettesitesek`
--

DROP TABLE IF EXISTS `helyettesitesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `helyettesitesek` (
  `ki` smallint(5) unsigned NOT NULL,
  `kit` smallint(5) unsigned NOT NULL,
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `ki_kit_idx` (`ki`,`kit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `helyettesitesek`
--

LOCK TABLES `helyettesitesek` WRITE;
/*!40000 ALTER TABLE `helyettesitesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `helyettesitesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_bolygok`
--

DROP TABLE IF EXISTS `hist_bolygok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_bolygok` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` smallint(5) unsigned NOT NULL,
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `tulaj` smallint(5) NOT NULL,
  `tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `pop` int(11) NOT NULL,
  PRIMARY KEY (`idopont`,`id`),
  KEY `tulaj_idopont_idx` (`tulaj`,`idopont`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_bolygok`
--

LOCK TABLES `hist_bolygok` WRITE;
/*!40000 ALTER TABLE `hist_bolygok` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_bolygok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_flotta`
--

DROP TABLE IF EXISTS `hist_csata_flotta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_flotta` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tulaj` smallint(5) NOT NULL DEFAULT '0',
  `tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `egyenertek_elotte` bigint(20) unsigned NOT NULL DEFAULT '0',
  `egyenertek_utana` bigint(20) unsigned NOT NULL DEFAULT '0',
  `tulaj_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `tulaj_szov_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `kozos` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `iranyito` smallint(6) NOT NULL DEFAULT '0',
  `iranyito_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `tp` int(10) unsigned NOT NULL DEFAULT '0',
  `iranyito_karrier` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `iranyito_speci` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `iranyito_rang` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `kezdo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`csata_id`,`flotta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_flotta`
--

LOCK TABLES `hist_csata_flotta` WRITE;
/*!40000 ALTER TABLE `hist_csata_flotta` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_flotta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_flotta_hajo`
--

DROP TABLE IF EXISTS `hist_csata_flotta_hajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_flotta_hajo` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `hajo_id` tinyint(3) unsigned NOT NULL,
  `serules` int(11) NOT NULL DEFAULT '0',
  `ossz_hp_elotte` int(11) NOT NULL DEFAULT '0',
  `ossz_hp_utana` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`csata_id`,`flotta_id`,`hajo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_flotta_hajo`
--

LOCK TABLES `hist_csata_flotta_hajo` WRITE;
/*!40000 ALTER TABLE `hist_csata_flotta_hajo` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_flotta_hajo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_flottamatrix`
--

DROP TABLE IF EXISTS `hist_csata_flottamatrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_flottamatrix` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `egyik_flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `masik_flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`csata_id`,`egyik_flotta_id`,`masik_flotta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_flottamatrix`
--

LOCK TABLES `hist_csata_flottamatrix` WRITE;
/*!40000 ALTER TABLE `hist_csata_flottamatrix` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_flottamatrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_lelottek`
--

DROP TABLE IF EXISTS `hist_csata_lelottek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_lelottek` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` smallint(5) NOT NULL DEFAULT '0',
  `lelott_ember` bigint(20) NOT NULL DEFAULT '0',
  `lelott_kaloz` bigint(20) NOT NULL DEFAULT '0',
  `lelott_zanda` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`csata_id`,`user_id`),
  KEY `user_idx` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_lelottek`
--

LOCK TABLES `hist_csata_lelottek` WRITE;
/*!40000 ALTER TABLE `hist_csata_lelottek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_lelottek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_sebzesek`
--

DROP TABLE IF EXISTS `hist_csata_sebzesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_sebzesek` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `tamado_flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tamado_hajo_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vedo_flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `vedo_hajo_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sebzes` int(11) NOT NULL DEFAULT '0',
  KEY `csata_idx` (`csata_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_sebzesek`
--

LOCK TABLES `hist_csata_sebzesek` WRITE;
/*!40000 ALTER TABLE `hist_csata_sebzesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_sebzesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csata_tpk`
--

DROP TABLE IF EXISTS `hist_csata_tpk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csata_tpk` (
  `csata_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` smallint(5) NOT NULL DEFAULT '0',
  `lelott` bigint(20) NOT NULL DEFAULT '0',
  `bukott` bigint(20) NOT NULL DEFAULT '0',
  `ossz_lelott` bigint(20) NOT NULL DEFAULT '0',
  `sajat_tp` int(11) NOT NULL DEFAULT '0',
  `ellen_tp` int(11) NOT NULL DEFAULT '0',
  `szerzett_tp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`csata_id`,`user_id`),
  KEY `user_idx` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csata_tpk`
--

LOCK TABLES `hist_csata_tpk` WRITE;
/*!40000 ALTER TABLE `hist_csata_tpk` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csata_tpk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_csatak`
--

DROP TABLE IF EXISTS `hist_csatak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_csatak` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `x` mediumint(9) NOT NULL DEFAULT '0',
  `y` mediumint(9) NOT NULL DEFAULT '0',
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `resztvett_egyenertek` bigint(20) unsigned NOT NULL DEFAULT '0',
  `megsemmisult_egyenertek` bigint(20) unsigned NOT NULL DEFAULT '0',
  `zanda` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_csatak`
--

LOCK TABLES `hist_csatak` WRITE;
/*!40000 ALTER TABLE `hist_csatak` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_csatak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_diplomacia_statuszok`
--

DROP TABLE IF EXISTS `hist_diplomacia_statuszok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_diplomacia_statuszok` (
  `idopont` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ki` smallint(5) NOT NULL DEFAULT '0',
  `kivel` smallint(5) NOT NULL DEFAULT '0',
  `mi` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `miota` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `kezdemenyezo` smallint(6) NOT NULL DEFAULT '0',
  `felbontasi_ido` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `felbontas_alatt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `felbontas_mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `diplo_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `diplo_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nyilvanos` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idopont`,`ki`,`kivel`),
  KEY `imkk_idx` (`idopont`,`mi`,`ki`,`kivel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_diplomacia_statuszok`
--

LOCK TABLES `hist_diplomacia_statuszok` WRITE;
/*!40000 ALTER TABLE `hist_diplomacia_statuszok` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_diplomacia_statuszok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_eroforrasok`
--

DROP TABLE IF EXISTS `hist_eroforrasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_eroforrasok` (
  `idopont` smallint(5) unsigned NOT NULL,
  `osztaly` tinyint(3) unsigned NOT NULL,
  `regio` tinyint(3) unsigned NOT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `db` bigint(20) NOT NULL,
  PRIMARY KEY (`idopont`,`osztaly`,`regio`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_eroforrasok`
--

LOCK TABLES `hist_eroforrasok` WRITE;
/*!40000 ALTER TABLE `hist_eroforrasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_eroforrasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_flottak`
--

DROP TABLE IF EXISTS `hist_flottak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_flottak` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `tulaj` smallint(5) NOT NULL,
  `x` mediumint(9) NOT NULL DEFAULT '0',
  `y` mediumint(9) NOT NULL DEFAULT '0',
  `tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `egyenertek` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idopont`,`id`),
  KEY `tulaj_idopont_idx` (`tulaj`,`idopont`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_flottak`
--

LOCK TABLES `hist_flottak` WRITE;
/*!40000 ALTER TABLE `hist_flottak` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_flottak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_gyarak`
--

DROP TABLE IF EXISTS `hist_gyarak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_gyarak` (
  `idopont` smallint(5) unsigned NOT NULL,
  `osztaly` tinyint(3) unsigned NOT NULL,
  `regio` tinyint(3) unsigned NOT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `db` bigint(20) NOT NULL,
  PRIMARY KEY (`idopont`,`osztaly`,`regio`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_gyarak`
--

LOCK TABLES `hist_gyarak` WRITE;
/*!40000 ALTER TABLE `hist_gyarak` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_gyarak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_hajok`
--

DROP TABLE IF EXISTS `hist_hajok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_hajok` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `tul` tinyint(4) NOT NULL DEFAULT '0',
  `ossz_hp` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idopont`,`id`,`tul`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_hajok`
--

LOCK TABLES `hist_hajok` WRITE;
/*!40000 ALTER TABLE `hist_hajok` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_hajok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_idopontok`
--

DROP TABLE IF EXISTS `hist_idopontok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_idopontok` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_idopontok`
--

LOCK TABLES `hist_idopontok` WRITE;
/*!40000 ALTER TABLE `hist_idopontok` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_idopontok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_szovetsegek`
--

DROP TABLE IF EXISTS `hist_szovetsegek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_szovetsegek` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` smallint(5) unsigned NOT NULL,
  `nev` varchar(80) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `rovid_nev` varchar(10) COLLATE utf8_hungarian_ci NOT NULL,
  PRIMARY KEY (`idopont`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_szovetsegek`
--

LOCK TABLES `hist_szovetsegek` WRITE;
/*!40000 ALTER TABLE `hist_szovetsegek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_szovetsegek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_termelesek`
--

DROP TABLE IF EXISTS `hist_termelesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_termelesek` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `brutto_termeles` bigint(20) NOT NULL,
  PRIMARY KEY (`idopont`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_termelesek`
--

LOCK TABLES `hist_termelesek` WRITE;
/*!40000 ALTER TABLE `hist_termelesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_termelesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_tp_szerzesek`
--

DROP TABLE IF EXISTS `hist_tp_szerzesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_tp_szerzesek` (
  `user_id` smallint(5) NOT NULL DEFAULT '0',
  `mikor` date NOT NULL DEFAULT '0000-00-00',
  `szerzett_tp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`mikor`),
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_tp_szerzesek`
--

LOCK TABLES `hist_tp_szerzesek` WRITE;
/*!40000 ALTER TABLE `hist_tp_szerzesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_tp_szerzesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hist_userek`
--

DROP TABLE IF EXISTS `hist_userek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hist_userek` (
  `idopont` smallint(5) unsigned NOT NULL,
  `id` smallint(5) unsigned NOT NULL,
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `szovetseg` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pontszam` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uccso_akt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `terulet` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pontszam_exp_atlag` bigint(20) unsigned NOT NULL DEFAULT '0',
  `helyezes` smallint(5) unsigned NOT NULL DEFAULT '0',
  `karrier` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `speci` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idopont`,`id`),
  KEY `idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hist_userek`
--

LOCK TABLES `hist_userek` WRITE;
/*!40000 ALTER TABLE `hist_userek` DISABLE KEYS */;
/*!40000 ALTER TABLE `hist_userek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kapcsak`
--

DROP TABLE IF EXISTS `kapcsak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kapcsak` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kapcsa` char(8) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kapcsak`
--

LOCK TABLES `kapcsak` WRITE;
/*!40000 ALTER TABLE `kapcsak` DISABLE KEYS */;
/*!40000 ALTER TABLE `kapcsak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kemriportok`
--

DROP TABLE IF EXISTS `kemriportok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kemriportok` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tulaj` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `bolygo_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `feladat_domen` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `feladat_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `darab` bigint(20) unsigned NOT NULL DEFAULT '0',
  `aktiv_darab` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pontos` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tul_b_idx` (`tulaj`,`bolygo_id`),
  KEY `tul_u_idx` (`tulaj`,`user_id`),
  KEY `szov_b_idx` (`tulaj_szov`,`bolygo_id`),
  KEY `szov_u_idx` (`tulaj_szov`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kemriportok`
--

LOCK TABLES `kemriportok` WRITE;
/*!40000 ALTER TABLE `kemriportok` DISABLE KEYS */;
/*!40000 ALTER TABLE `kemriportok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kod_aktivitas_log`
--

DROP TABLE IF EXISTS `kod_aktivitas_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kod_aktivitas_log` (
  `idopont` int(10) unsigned NOT NULL DEFAULT '0',
  `terkep_adatok` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idopont`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kod_aktivitas_log`
--

LOCK TABLES `kod_aktivitas_log` WRITE;
/*!40000 ALTER TABLE `kod_aktivitas_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `kod_aktivitas_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kp_transzfer_log`
--

DROP TABLE IF EXISTS `kp_transzfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kp_transzfer_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(6) NOT NULL DEFAULT '0',
  `user_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(6) NOT NULL DEFAULT '0',
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kp_transzfer_log`
--

LOCK TABLES `kp_transzfer_log` WRITE;
/*!40000 ALTER TABLE `kp_transzfer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `kp_transzfer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginek`
--

DROP TABLE IF EXISTS `loginek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginek` (
  `uid` smallint(5) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  `ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `technikai_login` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `kulon_ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `kulon_dn` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `sub_ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `sub_dn` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginek`
--

LOCK TABLES `loginek` WRITE;
/*!40000 ALTER TABLE `loginek` DISABLE KEYS */;
/*!40000 ALTER TABLE `loginek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginek_osszes`
--

DROP TABLE IF EXISTS `loginek_osszes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginek_osszes` (
  `uid` smallint(5) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  `ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `technikai_login` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `kulon_ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `kulon_dn` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `sub_ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `sub_dn` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  KEY `uid_mikor_idx` (`uid`,`mikor`) USING BTREE,
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginek_osszes`
--

LOCK TABLES `loginek_osszes` WRITE;
/*!40000 ALTER TABLE `loginek_osszes` DISABLE KEYS */;
/*!40000 ALTER TABLE `loginek_osszes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginek_osszes_10p`
--

DROP TABLE IF EXISTS `loginek_osszes_10p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginek_osszes_10p` (
  `uid` smallint(5) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  UNIQUE KEY `uid_mikor_idx` (`uid`,`mikor`) USING BTREE,
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginek_osszes_10p`
--

LOCK TABLES `loginek_osszes_10p` WRITE;
/*!40000 ALTER TABLE `loginek_osszes_10p` DISABLE KEYS */;
/*!40000 ALTER TABLE `loginek_osszes_10p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginek_osszes_ora`
--

DROP TABLE IF EXISTS `loginek_osszes_ora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginek_osszes_ora` (
  `uid` smallint(5) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  UNIQUE KEY `uid_mikor_idx` (`uid`,`mikor`) USING BTREE,
  KEY `mikor_idx` (`mikor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginek_osszes_ora`
--

LOCK TABLES `loginek_osszes_ora` WRITE;
/*!40000 ALTER TABLE `loginek_osszes_ora` DISABLE KEYS */;
/*!40000 ALTER TABLE `loginek_osszes_ora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_matrix`
--

DROP TABLE IF EXISTS `multi_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_matrix` (
  `ki` smallint(5) unsigned NOT NULL,
  `kivel` smallint(5) unsigned NOT NULL,
  `pont` bigint(20) NOT NULL DEFAULT '0',
  `magyarazat` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `minusz_pont` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ki`,`kivel`),
  KEY `kivel_idx` (`kivel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_matrix`
--

LOCK TABLES `multi_matrix` WRITE;
/*!40000 ALTER TABLE `multi_matrix` DISABLE KEYS */;
/*!40000 ALTER TABLE `multi_matrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_matrix_v2`
--

DROP TABLE IF EXISTS `multi_matrix_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_matrix_v2` (
  `ki` smallint(5) unsigned NOT NULL,
  `kivel` smallint(5) unsigned NOT NULL,
  `pont` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `darab` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ki`,`kivel`),
  KEY `kivel_idx` (`kivel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_matrix_v2`
--

LOCK TABLES `multi_matrix_v2` WRITE;
/*!40000 ALTER TABLE `multi_matrix_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `multi_matrix_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nagy_szovi_toplista`
--

DROP TABLE IF EXISTS `nagy_szovi_toplista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nagy_szovi_toplista` (
  `szov_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nev` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `pontszam_1` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_1` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_2` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_2` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_3` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_3` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_4` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_4` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_5` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_5` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_5` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_6` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_6` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_6` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_7` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_7` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_7` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_8` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_8` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_8` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_9` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_9` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_9` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_10` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_10` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_10` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_11` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_11` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_11` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_12` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_12` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_12` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_13` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_13` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_13` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_14` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_14` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_14` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_15` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_15` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_15` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_16` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_16` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_16` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_17` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_17` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_17` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_18` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_18` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_18` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_19` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_19` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_19` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_20` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_20` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_20` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_21` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_21` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_21` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_22` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_22` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_22` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_23` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_23` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_23` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_24` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_24` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_24` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_25` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_25` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_25` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_26` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_26` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_26` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `vegso_rang` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`szov_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nagy_szovi_toplista`
--

LOCK TABLES `nagy_szovi_toplista` WRITE;
/*!40000 ALTER TABLE `nagy_szovi_toplista` DISABLE KEYS */;
/*!40000 ALTER TABLE `nagy_szovi_toplista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nagy_toplista`
--

DROP TABLE IF EXISTS `nagy_toplista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nagy_toplista` (
  `user_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `pontszam_1` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_1` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_2` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_2` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_3` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_3` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_4` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_4` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_5` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_5` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_5` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_6` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_6` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_6` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_7` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_7` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_7` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_8` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_8` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_8` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_9` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_9` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_9` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_10` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_10` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_10` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_11` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_11` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_11` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_12` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_12` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_12` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_13` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_13` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_13` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_14` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_14` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_14` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_15` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_15` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_15` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_16` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_16` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_16` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_17` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_17` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_17` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_18` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_18` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_18` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_19` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_19` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_19` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_20` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_20` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_20` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_21` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_21` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_21` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_22` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_22` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_22` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_23` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_23` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_23` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_24` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_24` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_24` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_25` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_25` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_25` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `pontszam_26` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rang_26` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rangszazalek_26` smallint(5) unsigned NOT NULL DEFAULT '10000',
  `vegso_rang` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nagy_toplista`
--

LOCK TABLES `nagy_toplista` WRITE;
/*!40000 ALTER TABLE `nagy_toplista` DISABLE KEYS */;
/*!40000 ALTER TABLE `nagy_toplista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ostromok`
--

DROP TABLE IF EXISTS `ostromok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ostromok` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tipus` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flotta_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flotta_tulaj` smallint(5) NOT NULL DEFAULT '0',
  `flotta_tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `bolygo_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_tulaj` smallint(5) NOT NULL DEFAULT '0',
  `bolygo_tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ostromok`
--

LOCK TABLES `ostromok` WRITE;
/*!40000 ALTER TABLE `ostromok` DISABLE KEYS */;
/*!40000 ALTER TABLE `ostromok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `penz_transzfer_log`
--

DROP TABLE IF EXISTS `penz_transzfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `penz_transzfer_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(6) NOT NULL DEFAULT '0',
  `user_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(6) NOT NULL DEFAULT '0',
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penz_transzfer_log`
--

LOCK TABLES `penz_transzfer_log` WRITE;
/*!40000 ALTER TABLE `penz_transzfer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `penz_transzfer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `php_debug_log`
--

DROP TABLE IF EXISTS `php_debug_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `php_debug_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `szkript` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `idopont` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hasznalt_memoria` int(10) unsigned NOT NULL DEFAULT '0',
  `hasznalt_memoria_true` int(10) unsigned NOT NULL DEFAULT '0',
  `futasi_ido` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `php_debug_log`
--

LOCK TABLES `php_debug_log` WRITE;
/*!40000 ALTER TABLE `php_debug_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `php_debug_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premium_elofizetesek`
--

DROP TABLE IF EXISTS `premium_elofizetesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premium_elofizetesek` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fizetesi_mod` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `idotartam` tinyint(3) NOT NULL DEFAULT '30',
  `becsult_idotartam` smallint(6) NOT NULL DEFAULT '0',
  `szint` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `penznem` char(3) COLLATE utf8_hungarian_ci NOT NULL DEFAULT 'HUF',
  `szamlazasi_nev` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `szamlazasi_cim` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premium_elofizetesek`
--

LOCK TABLES `premium_elofizetesek` WRITE;
/*!40000 ALTER TABLE `premium_elofizetesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `premium_elofizetesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsek`
--

DROP TABLE IF EXISTS `smsek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsek` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `termekkod` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `vevokod` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `ido` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `tipus` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `fizetett` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `szoveg` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsek`
--

LOCK TABLES `smsek` WRITE;
/*!40000 ALTER TABLE `smsek` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `szabadpiaci_kotesek`
--

DROP TABLE IF EXISTS `szabadpiaci_kotesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `szabadpiaci_kotesek` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `termek_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vevo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `elado` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vevo_bolygo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `elado_bolygo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mennyiseg` bigint(20) unsigned NOT NULL DEFAULT '0',
  `arfolyam` int(10) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `referencia_arfolyam` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `szabadpiaci_kotesek`
--

LOCK TABLES `szabadpiaci_kotesek` WRITE;
/*!40000 ALTER TABLE `szabadpiaci_kotesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `szabadpiaci_kotesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `szim_log`
--

DROP TABLE IF EXISTS `szim_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `szim_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `idopont` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_npc` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_monetaris` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_termeles` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_felderites` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_flottamoral` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_flottak` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_csatak` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_ostromok` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_debug_elott` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_debug_utan` int(10) unsigned NOT NULL DEFAULT '0',
  `hossz_fog` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `szim_log`
--

LOCK TABLES `szim_log` WRITE;
/*!40000 ALTER TABLE `szim_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `szim_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terulet_valtozasok`
--

DROP TABLE IF EXISTS `terulet_valtozasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terulet_valtozasok` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` smallint(5) unsigned NOT NULL,
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `terulet` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terulet_valtozasok`
--

LOCK TABLES `terulet_valtozasok` WRITE;
/*!40000 ALTER TABLE `terulet_valtozasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `terulet_valtozasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tozsdei_gyertyak`
--

DROP TABLE IF EXISTS `tozsdei_gyertyak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tozsdei_gyertyak` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `termek_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `felbontas` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nyito_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `zaro_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `min_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `max_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `min5_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `max5_ar` int(10) unsigned NOT NULL DEFAULT '0',
  `forgalom` bigint(20) unsigned NOT NULL DEFAULT '0',
  `regio` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `regio_termek_felbontas_mikor_idx` (`regio`,`termek_id`,`felbontas`,`mikor`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tozsdei_gyertyak`
--

LOCK TABLES `tozsdei_gyertyak` WRITE;
/*!40000 ALTER TABLE `tozsdei_gyertyak` DISABLE KEYS */;
/*!40000 ALTER TABLE `tozsdei_gyertyak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tozsdei_kotesek`
--

DROP TABLE IF EXISTS `tozsdei_kotesek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tozsdei_kotesek` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vevo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `elado` smallint(5) unsigned NOT NULL DEFAULT '0',
  `termek_id` tinyint(3) unsigned NOT NULL,
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `arfolyam` int(10) unsigned NOT NULL DEFAULT '0',
  `mikor` datetime NOT NULL,
  `vevo_tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `elado_tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `vevo_bolygo_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `elado_bolygo_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `regio` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mikor_idx` (`mikor`) USING BTREE,
  KEY `regio_termek_mikor_idx` (`regio`,`termek_id`,`mikor`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tozsdei_kotesek`
--

LOCK TABLES `tozsdei_kotesek` WRITE;
/*!40000 ALTER TABLE `tozsdei_kotesek` DISABLE KEYS */;
/*!40000 ALTER TABLE `tozsdei_kotesek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transzfer_log`
--

DROP TABLE IF EXISTS `transzfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transzfer_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `eroforras_id` tinyint(3) unsigned NOT NULL,
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  `auto_vagy_ado` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_id_0` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_0` smallint(6) NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(6) NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transzfer_log`
--

LOCK TABLES `transzfer_log` WRITE;
/*!40000 ALTER TABLE `transzfer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `transzfer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transzfer_log_szurt`
--

DROP TABLE IF EXISTS `transzfer_log_szurt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transzfer_log_szurt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `bolygo_id_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `eroforras_id` tinyint(3) unsigned NOT NULL,
  `mennyiseg` bigint(20) unsigned NOT NULL,
  `mikor` datetime NOT NULL,
  `auto_vagy_ado` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_id_0` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tulaj_szov_0` smallint(6) NOT NULL DEFAULT '0',
  `tulaj_szov_1` smallint(6) NOT NULL DEFAULT '0',
  `tulaj_szov_2` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bidx1` (`bolygo_id_1`),
  KEY `bidx2` (`bolygo_id_2`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transzfer_log_szurt`
--

LOCK TABLES `transzfer_log_szurt` WRITE;
/*!40000 ALTER TABLE `transzfer_log_szurt` DISABLE KEYS */;
/*!40000 ALTER TABLE `transzfer_log_szurt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_szovi_valtasok`
--

DROP TABLE IF EXISTS `user_szovi_valtasok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_szovi_valtasok` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `regi_szov_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uj_szov_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mikor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_szovi_valtasok`
--

LOCK TABLES `user_szovi_valtasok` WRITE;
/*!40000 ALTER TABLE `user_szovi_valtasok` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_szovi_valtasok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userek_ossz`
--

DROP TABLE IF EXISTS `userek_ossz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userek_ossz` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `mikortol` datetime NOT NULL,
  `regip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo_so` char(32) COLLATE utf8_hungarian_ci NOT NULL,
  `session_so` char(32) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `token` char(32) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `jelszo_hash` char(128) COLLATE utf8_hungarian_ci NOT NULL,
  `session_ervenyesseg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `kitiltva` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `uccso_login` datetime NOT NULL,
  `uccso_login_ip` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `egy_gepesek` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uccso_akt` datetime NOT NULL,
  `szovetseg` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tisztseg` tinyint(3) NOT NULL DEFAULT '0',
  `szov_belepes` datetime NOT NULL,
  `tulaj_szov` smallint(6) NOT NULL DEFAULT '0',
  `ado_kotelezettseg` int(10) unsigned NOT NULL DEFAULT '0',
  `ado_teljesites` int(10) unsigned NOT NULL DEFAULT '0',
  `vagyon` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ugynokszam` bigint(20) unsigned NOT NULL DEFAULT '0',
  `likvidalando_ugynokszam` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pontszam` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pontszam_z_elott` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pontszam_z_utan` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inaktiv` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `raktarkapacitas` mediumint(8) unsigned NOT NULL DEFAULT '500',
  `vedelem` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_nem` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_szul` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stat_lakhely` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_telepules` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_vegzettseg` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_foglalkozas` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `techszint` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `techszint_ertesites` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ossz_nepesseg` bigint(20) unsigned NOT NULL DEFAULT '0',
  `bolygo_limit` smallint(5) unsigned NOT NULL DEFAULT '1',
  `premium` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `premium_alap` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `premium_emelt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uccso_cset_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `kin_keresztul_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `kin_keresztul_nev` varchar(36) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `avatar_crc` varchar(32) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `avatar_ext` varchar(3) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `beta` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `szamlazasi_nev` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `szamlazasi_cim` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `pontszam_exp_atlag` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inaktivitasi_ertesito` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fobolygo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `kalozcelpont` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `atvitt_premium` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `atvitt_premium_alap` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `atvitt_premium_emelt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `athozott_premium_ora` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nyelv` char(2) COLLATE utf8_hungarian_ci NOT NULL DEFAULT 'hu',
  `eredeti_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zanda_ref` varchar(250) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `zanda_session_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `zanda_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `eredeti_id_idx` (`eredeti_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userek_ossz`
--

LOCK TABLES `userek_ossz` WRITE;
/*!40000 ALTER TABLE `userek_ossz` DISABLE KEYS */;
INSERT INTO `userek_ossz` VALUES (1,'admin','test@example.hu','2012-12-01 17:01:21','localhost (127.0.0.1)','qzxfbwsntelisyigvzcygwctobycxrrh','','','c171c258f205d413764791206c8c90ae6615b4b9918d37877142f1fdbc3717c38f0dc9df3428c4fa03f35202008cb19476d33a580ccf243d67c5cbca289b7851','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','',0,'2012-12-01 17:01:21',0,0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,0,500,0,0,0,0,0,0,0,0,0,0,1,0,'2012-12-11 17:01:21','0000-00-00 00:00:00',0,0,'',1,'dvgaeolibnbvzioaraolmfhjgfuageqf','',0,'','',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'hu',1,'',0,0);
/*!40000 ALTER TABLE `userek_ossz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-12-04 23:43:47
